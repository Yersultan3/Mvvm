package com.example.retrofit.model

data class ValidateWithLogin(
    val username: String,
    val password: String,
    val request_token: String
)
